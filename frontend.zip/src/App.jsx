import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import DiscoverPage from './pages/DiscoverPage';
import CreateActivityPage from './pages/CreateActivityPage';

const App = () => (
  <Router>
    <Switch>
      <Route path="/discover" component={DiscoverPage} />
      <Route path="/create" component={CreateActivityPage} />
    </Switch>
  </Router>
);

export default App;
